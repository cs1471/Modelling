function lambdaEst = getLambdaEstMIMIpart(b,t2eval,basisObj)
% lambdaEst =
% getLambdaEstMIMIpart(b,t2eval,basisObj)
% 
% Use when considering only lambda1 or only lambda2. Evaluates the
% conditional intensity function with the estimated coefficients b in the
% given range t2eval.
%
% input:  
%      b: the estimated coefficients for the splines
%      t2val: (vector) range of values over which the splines of Lambdai will be
%             evaluated. Its entries need to be within the interval where
%             basisObjLambdai was defined
%      basisObj: basis object defining the spline basis for lambdailambda2
%
% output:
%      lambdaEst: matrix resulting of evaluating 
%  exp(b(1)) * exp( sum [b_ofLambdai * (splinesOfLambda1 evaluated in t2eval)])
%            that is, the estimated conditional intensity function
%----
% Castellanos. February, 2011.

% The range to get the mle of lambda is defined by t2eval x tminusS2eval

% 1. create functional data object, ie, estimatedCoefficients + basisObj
fdLambda = fd(b(2:end),basisObj);

% 2. evaluate the functional data objects on the points2eval
evalFdLambda= eval_fd(t2eval,fdLambda);

% 3. build the mle according the the glm model
expb1 = exp(b(1));
expL = exp(evalFdLambda);

lambdaEst = (expb1* expL);


end