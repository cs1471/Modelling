function y=mySineTrend(t,T,varargin)
% defines a sine function
% the optional input scaling factor helps to control the range of the
% function

if nargin==3
    scalingFactor = varargin{1};
else 
    scalingFactor = 1;
end

y= (sin(t*(2*pi)/T) +1)* scalingFactor;

end