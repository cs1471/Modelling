function [spikeTrain,timeCont,varargout] = generateSpikeTrainTrend(T,myTrendFun)
% generateSpikeTrainTrend:    
%       generates spike trains acording to the trend we defined: a sine
%       performing only one period.
%
% [spikeTrain,timeCont,lambda1] = generateSpikeTrainTrend(T,myTrendFun)
%
%   inputs:    
%       T: length of spike train to be generated (in seconds)
%       myTrendFun: handle of function describing the trend      
%
%   outputs:
%       spikeTrain: boolean cell array containing the generated spike train
%       timeCont:  cell vector containing the values of time of the firing rate
%                  defined as 0:binSize:T, where binSize is hardcoded to be
%                  1ms
%                  
%       Optional:  
%              lambda1: cell vector containing the instantaneous proba 
%                       of spike at each time point
%
%---
% Castellanos. January, 2011.

% Constant
binSize = 0.001; 
% Generate time period
timeCont=[0:binSize:T];

numTimePoints = length(timeCont);
spikeTrainCell = cell(1,numTimePoints);
lambda1 = cell(1,numTimePoints);
% Generate spike
for idx =1:numTimePoints
    t = timeCont(idx);
    lambda1{idx} =  myTrendFun(t);   
  
    if binornd(1,lambda1{idx})==1 % fire!
        spikeTrainCell{idx}=1;
    else
        spikeTrainCell{idx}=0;
    end
end

% return the spike train in a array of cells
spikeTrain = spikeTrainCell;

if nargout>=3
    varargout(1) = {lambda1};
end


end