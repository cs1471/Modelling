function h = hazardGamma(shapeGamm,scaleGamm,arg)
% calculates the hazard function of the gamma distribution 
% with shape parameter shapeGamm, and scale parameter scaleGamm, evaluated on arg
%
% gamma and gammainc are matlab functions. Type help('gamma') or 
% help('gammainc') to see their  documentation
%
% Recall:  hazard = pdf / (1-cdf)
% ---
% Castellanos. January, 2011


h = ((arg.^(shapeGamm-1)) .* exp(-arg/scaleGamm) ) ./ ( (gamma(shapeGamm)-gamma(shapeGamm)*gammainc(arg/scaleGamm,shapeGamm)) * scaleGamm^shapeGamm);

end