function lambdaEst = getLambdaEstMIMI(b,t2eval,basisObjLambda1,tminusS2eval,basisObjLambda2)
% lambdaEst =
% getLambdaEstMIMI(b,t2eval,basisObjLambda1,tminusS2eval,basisObjLambda2)
%
% input:  
%      b: the estimated coefficients for the splines
%      t2val: (vector) range of values over which the splines of Lambda1 will be
%             evaluated. Its entries need to be within the interval where
%             basisObjLambda1 was defined
%      basisObjLambda1: basis object defining the spline basis for lambda1
%      tminusS2eval: (vector) range of values over which the splines of
%              Lambda2 will be evaluated. Its entries need to be within the
%              interval where basisObjLambda2was defined
%      basisObjLambda2: basis object defining the spline basis for lambda2
%
% output:
%      lambdaEst: matrix resulting of evaluating 
%  exp(b(1)) * exp( sum [b_ofLambda1 * (splinesOfLambda1 evaluated in t2eval)]) *
%              exp( sum [b_ofLambda2 * (splinesOfLambda2 evaluated in tminusS2eval)])  
%            that is, the estimated conditional intensity function
%----
% Castellanos. February, 2011.

% The range to get the mle of lambda is defined by t2eval x tminusS2eval

% 1. create functional data object, ie, estimatedCoefficients + basisObj
fdLambda1 = fd(b(2:(getnbasis(basisObjLambda1)+1)),basisObjLambda1);
fdLambda2 = fd(b((2+getnbasis(basisObjLambda1)):end),basisObjLambda2);

% 2. evaluate the functional data objects on the points2eval

evalFdLambda1= eval_fd(t2eval,fdLambda1);
evalFdLambda2= eval_fd(tminusS2eval,fdLambda2);

% 3. build the mle according the the glm model
expb1 = exp(b(1));
expL1 = exp(evalFdLambda1);
expL2 = exp(evalFdLambda2);

lambdaEst = (expb1* expL1 *  expL2')';


end