% Castellanos, 2011.

%% Generate spike trains acording to IMI model
% given a vector lambda of conditional intensity at time t generate spike
% trains
clear
close all
 
T=1;                    % time in seconds
includeLambda1=1;
fLambda1 = @(t) mySineTrend(t,T);

shapeGamm = 3;
scaleGamm = 1/4;
fLambda2 = @(tMinusSstar) hazardGamma(shapeGamm,scaleGamm,tMinusSstar);
%       shapeGamm: shape parameter of the gamma distribution required to define its
%              hazard function, that in our case, constitutes lambda2
%       scaleGamm: scale/rate parameter of the gamma distribution required to define
%                 hazard function its 

numSpkTrains =30;

numTimeSamples = (T/.001)+1;
allSpkTrains = nan(numSpkTrains,numTimeSamples);
allSstar = nan(numSpkTrains,numTimeSamples);
allLambda = nan(numSpkTrains,numTimeSamples);
allLambda1 =nan(numSpkTrains,numTimeSamples);
allLambda2 =nan(numSpkTrains,numTimeSamples);

for i=1:numSpkTrains
    i
    [spkTrain,timeCont,sStar,lambda,lambda2,lambda1] = generateSpikeTrainMIMI(T,fLambda2,includeLambda1,fLambda1);
    allSpkTrains(i,:)=[spkTrain{:}];
    allSstar(i,:) = [sStar{:}];
    allLambda(i,:) = [lambda{:}];
    allLambda2(i,:) = [lambda2{:}];
    allLambda1(i,:) = [lambda1{:}];
end

%% Obtain firing rate, PSTH, ISIs histogram and CV

frMIMI = sum(sum(allSpkTrains)) /(T*numSpkTrains)
figure
subplot(2,1,1)
hist(find(sum(allSpkTrains)),30)
set(gca,'fontsize',13)
title(strcat('PSTH --> ',num2str(numSpkTrains),' spike trains, mMIM: \lambda = \lambda_1 * \lambda_2. FiringRate = ',num2str(frMIMI)),'fontsize',13)

% ISIs and cv
[numSpkTrains,numTimeSamples] =size(allSpkTrains);

allSpkTimes = [];
for i=1:numSpkTrains
  allSpkTimes = [allSpkTimes timeCont(find(allSpkTrains(i,:)))]; 
end

allSpkTimes = sort(allSpkTimes);
allIsis = diff(allSpkTimes);
cv = std(allIsis)/mean(allIsis)

subplot(2,1,2)
hist(allIsis,100)
set(gca,'fontsize',13)
title(strcat('ISIs hist --> ', num2str(numSpkTrains), 'spike trains, mMIM: \lambda = \lambda_1 * \lambda_2. cv = ',num2str(cv)),'fontsize',13);

%%  Save data

% outputDir = 'mIMIfitting';
% outputFile = 'mIMIdata2fit'
% mkdir(outputDir)
% save(fullfile(outputDir,outputFile),'T','shapeGamm','scaleGamm','includeLambda1','numSpkTrains','numTimeSamples','allSpkTrains', ...
%     'timeCont','allSstar','allLambda','allLambda2','allLambda1','allIsis','cv','allSpkTimes')

%% Prepare data for fitting and fitting

t0 = 0;    % miliseconds
t1 = 1000; % miliseconds

spikesAll = reshape(allSpkTrains(1:numSpkTrains,:)',numel(allSpkTrains(1:numSpkTrains,:)),1);
tVec = repmat([t0:t1]',numSpkTrains,1);
sStar = reshape(allSstar(1:numSpkTrains,:)',numel(allSstar(1:numSpkTrains,:)),1);
        sStar =  1000* sStar; % in miliseconds

options.form = 'fullMIMI';
options.knotsLambda1 = linspace(t0,t1,8); % experiment with this range!
                              % (remember that 
                              % you must include t0 as the first element of
                              % knots and t1 as the last) .. how sensitive
                              % is the solution to the selection of knots?
                              % if you put too many knots the model might
                              % overfit! (try 15 knots for instance and compare the
                              % visualization of lambdaEst, lambaTrue --below; with PSTH -- above)
options.knotsLambda2 = [t0 10 max(tVec-sStar)];  % experiment with this range!
                              % (remember that 
                              % you must include t0 as the first element of
                              % knots and max(tVec-sStar) as the last) ...
                              % how sensitive is the solution to the 
                              % selection of knots?                             
                              

%fit model
 [b,basisAndFDobj]= fitMIMI([t0 t1],spikesAll,tVec,options,sStar) ;
 
 

 basisObjLambda1 = basisAndFDobj{1,2};
 basisMatLambda1 = basisAndFDobj{1,3};
 
 basisObjLambda2 = basisAndFDobj{2,2};
 basisMatLambda2 = basisAndFDobj{2,3};
 
 %% Obatain lambdaEst
 
 % select a grid
t2eval =0:t1;
t1Lambda2 = max(tVec-sStar);
tminusS2eval = 0:t1Lambda2;

lambdaEst =getLambdaEstMIMI(b,t2eval,basisObjLambda1,tminusS2eval,basisObjLambda2);


 
 
%% Obtain and plot lambdaEst


figure
imagesc(lambdaEst,[0 0.27])
colorbar
title(['Extimated \lambda, ' options.form ],'fontsize', 15)
xlabel('t (mS)','fontsize', 15)
ylabel('t-s*(t) (mS)','fontsize', 15)
set(gca,'fontsize',13)

%% Plot true lambda
T=1;
% Constant
binSize = 0.001; 
% Generate time period
timeCont=[0:binSize:T];
numTimePoints=length(timeCont);

shapeGamm =3;
scaleGamm = 1/4;

maxTmS =max(tVec-sStar);

doTmS = linspace(0,maxTmS/1000,maxTmS);

lambda1true =sin(timeCont*(2*pi)/T) +1;
lambda2true = hazardGamma(shapeGamm,scaleGamm,doTmS);
lambdaTrue = (lambda1true'*lambda2true)';

figure
imagesc(lambdaTrue,[0 0.27])
colorbar
title(['True \lambda, ' options.form],'fontsize', 15)
xlabel('t (mS)','fontsize', 15)
ylabel('t-s*(t) (mS)','fontsize', 15)
set(gca,'fontsize',13)

%% ks plot

expL1orig =exp(basisMatLambda1 * b(2:getnbasis(basisObjLambda1)+1));
expL2orig = exp(basisMatLambda2*b(getnbasis(basisObjLambda1)+2:end));
expb1 = exp(b(1));
lambdaOrig = expb1* (expL1orig .*  expL2orig);



ksStat = doKStest(lambdaOrig,spikesAll);


%%  marginal intensity

allTMS = repmat(timeCont,numSpkTrains,1) * 1000;
allSstarMS = allSstar*1000;

lambdaMarg = nan(numSpkTrains,numTimeSamples);

for tt=1:numTimeSamples
    
    % obtain arguments
    tsample = allTMS(:,tt);
    tminusSsample = allTMS(:,tt)-allSstarMS(:,tt);
    temp=getLambdaEstMIMI(b,tsample, basisObjLambda1,tminusSsample,basisObjLambda2);     
    lambdaMarg(:,tt)= temp(:,1);

end

% plot both 
figure
hold on
plot(mean(allLambda),'b')
plot(mean(lambdaMarg),'r')
xlim([allTMS(1) allTMS(end)])
xlabel('Time (mS)','fontsize',13)
ylabel(' \lambda_{est}(t)','fontsize',13)
legend({'True marginal' 'Estimated lambda'},'fontsize',13,'location','northeast')
set(gca,'fontsize',13)
