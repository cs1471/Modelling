% Castellanos, 2011.

%%  generate 30 spike trains of 1 sec long with lambda(t) \prop sin(t)
clear
 
T=1;
scalingFactor = 1/50;   % NOTE: when considering only lambda2 or the fullMIMI model
                        % set scalingFactor to 1.
fLambda1 = @(t) mySineTrend(t,T,scalingFactor);
numSpkTrains =30;
numTimeSamples = (T/.001)+1;
allSpkTrains = nan(numSpkTrains,numTimeSamples);
allLambda1 = nan(numSpkTrains,numTimeSamples); 

% generate spike trains:
for i=1:numSpkTrains
    i
    [spikeTrain,timeCont,lambda1] = generateSpikeTrainTrend(T,fLambda1);
    % NOTE: when considering only lambda2 or the fullMIMI model
    %       you will use a function called generateSpikeTrainIMI -- it takes 
    %       different inputs, be sure to check its documentation
    allSpkTrains(i,:)=[spikeTrain{:}];
    allLambda1(i,:) =[lambda1{:}] ;
end


% Obtain isis of whole population only with lambda1(t) = sin(t)

[numSpkTrains,numTimeSamples] =size(allSpkTrains);

allSpkTimes = [];
for i=1:numSpkTrains
  allSpkTimes = [allSpkTimes timeCont(find(allSpkTrains(i,:)))]; 
end

%% plot stuff
figure
subplot(2,1,1)
hist(find(sum(allSpkTrains)),30) % PSTH
xlabel('Miliseconds','fontsize',13)
fr = sum(sum(allSpkTrains))/(T*numSpkTrains)
title(strcat('PSTH -->',num2str(numSpkTrains),'  spike trains, \lambda(t) =  \lambda_1(t).    FiringRate = ',num2str(fr)),'fontsize',13)
set(gca,'fontsize',13)

% Obtain isis of whole population only with lambda1(t) = sin(t)
% you need to pool the spike times across trials
[numSpkTrains,numTimeSamples] =size(allSpkTrains);

allSpkTimes = [];
for i=1:numSpkTrains
  allSpkTimes = [allSpkTimes timeCont(find(allSpkTrains(i,:)))]; 
end

allSpkTimes = sort(allSpkTimes);
allIsis = diff(allSpkTimes);
cv = std(allIsis)/mean(allIsis)

subplot(2,1,2)
hist(allIsis,100)
xlabel('Seconds','fontsize',13)
title(strcat('ISIs hist --> ', num2str(numSpkTrains), '  spike trains,  \lambda(t) = \lambda_1(t) \propto sin(t). cv = ',num2str(cv)),'fontsize',13);

set(gca,'fontsize',13)

%% Save data  --- if you want to save your data, uncomment this block
% outputDir = 'mIMIfitting';
% outputFile = 'mIMIdata2fit-onlyTrend'
% mkdir(outputDir)
% save(fullfile(outputDir,outputFile),'T','scalingFactor','numSpkTrains','numTimeSamples','allSpkTrains', ...
%     'timeCont','allLambda1','allIsis','cv','allSpkTimes')

%% Prepare data for fitting:

t0 = 0;    % miliseconds
t1 = 1000; % miliseconds

spikesAll = reshape(allSpkTrains(1:numSpkTrains,:)',numel(allSpkTrains(1:numSpkTrains,:)),1);
tvec = repmat([t0:t1]',numSpkTrains,1);

options.form = 'onlyLambda1';

% fit the model:
[b,basisAndFDobj]= fitMIMI([t0 t1],spikesAll,tvec,options) ;

 
 basisObjLambda1 = basisAndFDobj{2};
 basisMatLambda1 = basisAndFDobj{3};
 
%% Obatain lambdaEst
 
% select a range to evaluate:
 t2eval =0:t1;

% get lambdaEst:
lambdaEst =getLambdaEstMIMIpart(b,t2eval,basisObjLambda1);   
 

%% Plot lambda est vs lambda true
 
figure
hold on
plot(allLambda1(1,:),'r','linewidth',3);
plot(lambdaEst,'--b','linewidth',4);
xlim([t0 t1]);
legend({'true \lambda' ' \lambda estimate'},'location','SouthWest','fontsize',13);
set(gca,'fontsize',13);


%% KS plots
% plug in the estimate of lambda in the original data
lambdaEstOrigData = exp(b(1)+basisMatLambda1*b(2:end));
hold off

ksStat = doKStest(lambdaEstOrigData,spikesAll);

