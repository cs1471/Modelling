function [b,basisAndFDobj]=fitMIMI(t0t1,spikesAll,tVec,options,varargin) 
% fitMIMI
%
% inputs: 
%        t0t1 = vector size 2 x 1 containing two time points *in miliseconds*
%               t0 = the start of the time period where the spike train is
%                    defined
%               t1 = the end of the time period
%        spikesAll = vector of size (numTrials*numTimePoints) x 1
%                    where numTimepoints = the number of time samples in a
%                    trial (= length(t0:t1) )
%                    - it contains the spiking activity of the neuron
%                    (zeros or ones) along all of the trials stacked
%                    together
%        tVec = vector of size (numTrials*numTimePoints) x 1
%               containing the time points for each trial
%        options = struct with field form
%                options.form can take the values:
%                'onlyLambda1' 'onlyLambda2' 'fullMIMI' acording to the
%                model you want to fit.
%     (Optional:)
%        sStar = vector of size (numTrials*numTimePoints) x 1
%               containing the times of the last spike: this is a required
%               input if options.form is 'onlyLambda2' or 'fullMIMI'
%        
%   outputs:
%        b = the estimated coefficients given by the glmfit function, and 
%            corresponding to the coefficients of the independent term, the
%            coefficients of the spline basis for lambda1 and the coefficients
%            for the spline basis of lambda2
%       basisAndFDobj:  a cell array of size numRows x 3
%                       numRows depends on the model being fitted. The
%                       first column of this array contains the function we
%                       are refering to (lambda1 and/or lambda2), the
%                       second column contains the basisObj object and the
%                       third column the functional data object (ie the
%                       basisObj evaluated at the given tVec or tVec-sStar
%                       respectively)
%                           
% Could be implemented:
% - not require the user to give sStar, but calculate it from tVec and
%   spikesAll
% - give as output: dev,stats
%-----
% Castellanos. January, 2008.

% what model to fit?
modelType = lower(options.form);

t0 = t0t1(1);
t1 = t0t1(2);

norder = 4; % for both splines

X=[];

if strcmpi(modelType,'onlyLambda1') || strcmpi(modelType,'fullMIMI')
    %%%------------
    % lambda1
    % prepare vector of arguments to plug in in the matrix:
    argLambda1 = tVec;

  

    % Define B-pline basis for lambda1
    rangevalLambda1 = [t0 t1]; 
    if isfield(options,'knotsLambda1')==1
        breaksLambda1 = options.knotsLambda1;
    else
        breaksLambda1 =  linspace(t0,t1,3);
    end
    nbasisLambda1 = norder+ length(breaksLambda1)-2; 
    basisObjLambda1 = create_bspline_basis(rangevalLambda1,nbasisLambda1,norder,breaksLambda1);

    % Evaluate B-splines basis on argLambda1 (= tVec (time))
    basisMatrixLambda1 = eval_basis(argLambda1,basisObjLambda1);
    basisMatLambda1 = full(basisMatrixLambda1); % convert from sparse matrix to full matrix

    %%%-------------
    % Put info in design matrix 
    X = [X basisMatLambda1];
end

if strcmpi(modelType,'onlyLambda2') || strcmpi(modelType,'fullMIMI')
    if nargin==5
        sStar = varargin{1};
    %%%------------
    % lambda2
    % prepare vector of arguments to plug in in the matrix:
    argLambda2 = tVec - sStar;

    % Define B-pline basis for lambda2
    t1Lambda2 =max(argLambda2);
    rangevalLambda2 =  [t0 t1Lambda2];
    if isfield(options,'knotsLambda2')==1
        breaksLambda2 = options.knotsLambda2;
    else
        breaksLambda2 =   [t0 10 t1Lambda2];
    end
    nbasisLambda2 = norder+ length(breaksLambda2)-2; 
    basisObjLambda2 = create_bspline_basis(rangevalLambda2,nbasisLambda2,norder,breaksLambda2);

    % Evaluate B-splines basis on argLambda2 (= tVec-sStar (time since last spike))
    basisMatrixLambda2 = eval_basis(argLambda2,basisObjLambda2);
    basisMatLambda2 = full(basisMatrixLambda2); % convert from sparse matrix to full matrix

    %%%-------------
    % Put info in design matrix 
    X = [X basisMatLambda2];
    else
        disp(['Error: you need to provide as input sStar!!' ]);
        % TODO: creat a function that given tVec and spikesAll, you get sStar
    end
end

% (perturb for numerical stability)
    [nRows,nCols]=size(X);
X = X + 0.001*rand(nRows,nCols)-0.0005;

%%% Fit the model:
[b,dev,stats]=glmfit(X,spikesAll,'poisson');


% Prepare to return basis and functional data object objects
if strcmpi(modelType,'onlyLambda1')
    basisAndFDobj = cell(1,3);
    basisAndFDobj{1} = 'lambda1';
    basisAndFDobj{2} = basisObjLambda1;
    basisAndFDobj{3} = basisMatLambda1;
end

if strcmpi(modelType,'onlyLambda2')
    basisAndFDobj = cell(1,3);
    basisAndFDobj{1} = 'lambda2';
    basisAndFDobj{2} = basisObjLambda2;
    basisAndFDobj{3} = basisMatLambda2;
end

if strcmpi(modelType,'fullMIMI')
    basisAndFDobj = cell(2,3);
    basisAndFDobj{1,1} = 'lambda1';
    basisAndFDobj{1,2} = basisObjLambda1;
    basisAndFDobj{1,3} = basisMatLambda1;
    basisAndFDobj{2,1} = 'lambda2';
    basisAndFDobj{2,2} = basisObjLambda2;
    basisAndFDobj{2,3} = basisMatLambda2;
end

% Obtain lambdaEst
if nargout == 3
    switch modelType
        case lower('fullMIMI')
            t2eval =0:t1;
            tminusS2eval = 0:t1Lambda2;
            lambdaEst =getLambdaEstMIMI(b,t2eval,basisObjLambda1,tminusS2eval,basisObjLambda2);
        case lower('onlyLambda2')
            tminusS2eval = 0:t1Lambda2;
            lambdaEst =getLambdaEstMIMIpart(b,tminusS2eval,basisObjLambda2);            
        case lower('onlyLambda1')
            t2eval =0:t1;
            lambdaEst =getLambdaEstMIMIpart(b,t2eval,basisObjLambda1);   
        otherwise
            lambdaEst =-1;
            disp('Warning: check the modelType you defined.')
    end
    varargout(1) = {lambdaEst};
end

end