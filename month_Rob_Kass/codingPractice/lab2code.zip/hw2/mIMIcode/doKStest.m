function ksStat = doKStest(lambdaEstOrigData,spikesOrig)
% doKStest
%
%     inputs:
%           lambdaEstOrigData: vector (nx1) 
%                    the conditional intensity function defined
%                    by the learnt coefficients, evaluated in the original
%                    data.
%           spikesOrig: vector (nx1)
%                    contains the spike counts in bins
%          
%     output: 
%           ksStat:  KS statistic
%           the KS plot
%
% ---
% by Uri Eden
% modified by Castellanos. January 2011.

timestep = 1;
lambdaInt = 0;
j=0;
for t=1:length(spikesOrig),
    lambdaInt = lambdaInt + lambdaEstOrigData(t)*timestep;
    if (spikesOrig(t)==1)
        j = j + 1;
        KS(j) = 1-exp(-lambdaInt);
        lambdaInt = 0;
    end;
end;
KSSorted = sort( KS );
N = length( KSSorted);

ksStat = max(abs(KSSorted - ([1:N]-.5)/N));

figure;
hold on
plot( ([1:N]-.5)/N, KSSorted, 'b', 'linewidth',3)
plot( 0:.01:1,0:.01:1, 'g','linewidth',2)
plot(0:.01:1, [0:.01:1]+1.36/sqrt(N), 'r', 'linewidth',2)
plot(0:.01:1,[0:.01:1]-1.36/sqrt(N), 'r','linewidth',2 );
axis( [0 1 0 1] );
xlabel('Uniform CDF');
ylabel('Empirical CDF of Rescaled ISIs');
title(strcat('KS Plot with 95% Confidence Intervals. KS-stat: ',num2str(ksStat)));




end