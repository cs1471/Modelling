function [spikeTrain,timeCont,varargout] = generateSpikeTrainMIMI(T,funLambda2,includeLambda1,varargin)
% generateSpikeTrainMIMI:    generates spike trains acording to mIMI model
%
% [spikeTrain,timeCont,sStar,lambda,lambda2,lambda1] =
% generateSpikeTrainMIMI(T,funLambda2,includeLambda1);
%
%   inputs:    
%       T: length of spike train to be generated (in seconds)
%       funLambda2: a handle to the function the user defined as lambda2
%       includeLambda1: boolean that determines whether to include lambda1
%                       in the definition of the conditional intensity 
%                       function or not. Recall: lambda = lambda1 * lambda2            
%       Optional:
%           funLambda1: a handle to the function the user defined as
%                       lambda1, if nothing is provided, the default is
%                       the constant function 1.
%           scalingFactor: scalar factor to multiply by lambda, used to 
%                          ensure the desired firing rate
%                          (determined heuristically)
%
%   outputs:
%       spikeTrain: boolean cell array containing the generated spike train
%       timeCont:  cell vector containing the values of time of the firing rate
%                  defined as 0:binSize:T, where binSize is hardcoded to be
%                  1ms
%                  
%       Optional:  (all the following are cell vectors)
%              sStar: time of the last spike for each time point
%              lambda: value of lambda along time
%              lambda2: value of lambda2 along time
%              lambda1: value of lambda1 along time (in this case sin
%                       function of only one period)
%
%
%---
% Castellanos. January, 2011.

% Constant
binSize = 0.001; 
% Generate time period
timeCont=[0:binSize:T];
numTimePoints = length(timeCont);

if nargin>=4
    funLambda1 =varargin{1};
else
    funLambda1 = ones(numTimePoints,1);% @(t) myLambda1(t,T);
end

if nargin==5
    scalingFactor =varargin{2};
else
    scalingFactor =1;
end

% initialize arrays
spikeTrainCell = cell(1,numTimePoints);
sStarCell = cell(1,numTimePoints);
lambda2 =cell(1,numTimePoints);
lambda = cell(1,numTimePoints);
sStar =0;

if includeLambda1
    lambda1 =cell(1,numTimePoints);
end

% Generate the spikeTrain time sample by time sample
for idx =1:numTimePoints
    if mod(idx,10000)==0
        disp(strcat('Generating spike train. Time point: ', num2str(idx),'/', num2str(numTimePoints)));
    end
    t = timeCont(idx);
   
    sStarCell{idx}= sStar;
    arg = t-sStar;
    p = scalingFactor * funLambda2(arg);
    lambda2{idx} = p;
    
    
    % include Lambda1
    if includeLambda1 ==1
        % multiply by lambda1
        lambda1{idx} = funLambda1(t);
        p = p *  lambda1{idx};
    end
    
    lambda{idx} = p;
    
    % Draw a bernoulli sample
    if binornd(1,p)==1 % fire!
        spikeTrainCell{idx}=1;
        sStar = t; % next iteration this is the time of last spike
    else
        spikeTrainCell{idx}=0;
    end
    
end


spikeTrain = spikeTrainCell;

% Optional output arguments:

if nargout>=3
    varargout(1) = {sStarCell};
end

if nargout>=4
    varargout(2) = {lambda};
end

if nargout>=5
    varargout(3) = {lambda2};
end

if nargout>=6
    if includeLambda1 ==1
        varargout(4) = {lambda1};
    else
        varargout(4) = {'Lambda1 was not included in the conditional intensity function.'};
    end
end


end