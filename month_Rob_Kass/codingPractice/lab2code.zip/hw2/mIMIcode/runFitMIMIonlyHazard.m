% Castellanos, 2011.

%% Generate 30 spike trains of 1 sec long with lambda(t) = lambda2(t-s*(t))
clear
close all
 
T=1;

scalingFactor = 1;
includeLambda1=0;
numSpkTrains =30;

% define the function for lambda2:
shapeGamm =3;
scaleGamm = 1/3.5;
fLambda2 = @(tMinusSstar) hazardGamma(shapeGamm,scaleGamm,tMinusSstar);

numTimeSamples = (T/.001)+1;
allSpkTrains = nan(numSpkTrains,numTimeSamples);
allSstar = nan(numSpkTrains,numTimeSamples);
allLambda = nan(numSpkTrains,numTimeSamples);
allLambda2 =nan(numSpkTrains,numTimeSamples);

% generate spike trains:
for i=1:numSpkTrains
    i
    [spkTrain,timeCont,sStar,lambda,lambda2] = generateSpikeTrainMIMI(T,fLambda2,includeLambda1);
    allSpkTrains(i,:)=[spkTrain{:}];
    allSstar(i,:) = [sStar{:}];
    allLambda(i,:) = [lambda{:}];
    allLambda2(i,:) = [lambda2{:}];

end

%% Obtain firing rate, PSTH, ISIs histogram and CV

frMIMI = sum(sum(allSpkTrains)) /(T*numSpkTrains)
figure
subplot(2,1,1)
hist(find(sum(allSpkTrains)),30) % PSTH
set(gca,'fontsize',13)
title(strcat('PSTH --> ',num2str(numSpkTrains),' spike trains, \lambda(t) =  \lambda_2(t). FiringRate = ',num2str(frMIMI)),'fontsize',13)

% ISIs and cv
[numSpkTrains,numTimeSamples] =size(allSpkTrains);

allSpkTimes = [];
for i=1:numSpkTrains
  allSpkTimes = [allSpkTimes timeCont(find(allSpkTrains(i,:)))]; 
end

allSpkTimes = sort(allSpkTimes);
allIsis = diff(allSpkTimes);
cv = std(allIsis)/mean(allIsis)

subplot(2,1,2)
hist(allIsis,100) % ISIs histogram
set(gca,'fontsize',13)
title(strcat('ISIs hist --> ', num2str(numSpkTrains), 'spike trains,\lambda(t) =  \lambda_2(t). cv = ',num2str(cv)),'fontsize',13);

 %%  Save data  --- if you want to save your data uncomment this block
% 
% outputDir = 'mIMIfitting';
% outputFile = 'mIMIdata2fit-onlyHazard'
% mkdir(outputDir)
% save(fullfile(outputDir,outputFile),'T','shapeGamm','scaleGamm','scalingFactor','includeLambda1','numSpkTrains','numTimeSamples','allSpkTrains', ...
%     'timeCont','allSstar','allLambda','allLambda2','allIsis','cv','allSpkTimes')

%% Prepare data for fitting:

t0 = 0;    % miliseconds
t1 = 1000; % miliseconds

spikesAll = reshape(allSpkTrains(1:numSpkTrains,:)',numel(allSpkTrains(1:numSpkTrains,:)),1);
tVec = repmat([t0:t1]',numSpkTrains,1);
sStar = reshape(allSstar(1:numSpkTrains,:)',numel(allSstar(1:numSpkTrains,:)),1);
        sStar =  1000* sStar; % in miliseconds
options.form = 'onlyLambda2';

%fit the model:
[b,basisAndFDobj]= fitMIMI([t0 t1],spikesAll,tVec,options,sStar) ;

 basisObjLambda2 = basisAndFDobj{2};
 basisMatLambda2 = basisAndFDobj{3};
 
%% Obatain lambdaEst - on all the possible values of t-s(t) obtained in our sample

t1Lambda2 = max(tVec-sStar);
tminusS2eval = 0:t1Lambda2;
lambdaEst =getLambdaEstMIMIpart(b,tminusS2eval,basisObjLambda2);     


%% Plot true lambda vs lambda estimated (on a range of values to evaluate)

shapeGamm =3;
scaleGamm = 1/3.5;
x=tminusS2eval/1000; 
h=hazardGamma(shapeGamm,scaleGamm,x);

figure
hold on
plot(x,h,'r','linewidth',3)
plot(x,lambdaEst,'--b','linewidth',4)
legend({'true \lambda' '\lambda estimate' },'location','NorthWest','fontsize',13)
xlabel('Time (seconds)','fontsize',13)
set(gca,'fontsize',13)
%% KS test

% plug in the estimate of lambda in the original data
lambdaEstOrigData = exp(b(1)+basisMatLambda2*b(2:end));

ksStat = doKStest(lambdaEstOrigData,spikesAll);

%%  marginal intensity

allTMS = repmat(timeCont,numSpkTrains,1) * 1000; % multipling by 1000 to set in mS
allSstarMS = allSstar*1000;

lambdaMarg = nan(numSpkTrains,numTimeSamples);

for s=1:numSpkTrains
    % obtain argument
    tminusSsample = allTMS(s,:)-allSstarMS(s,:);
    % obtain lambda estimate
    lambdaMarg(s,:) =getLambdaEstMIMIpart(b,tminusSsample,basisObjLambda2);     
end

% plot both 
figure
hold on
plot(mean(allLambda2),'b')
plot(mean(lambdaMarg),'r')
xlim([allTMS(1) allTMS(end)])
xlabel('Time (mS)','fontsize',13)
ylabel(' \lambda_{est}(t)','fontsize',13)
legend({'True marginal' 'Estimated lambda'},'fontsize',13,'location','southeast')
set(gca,'fontsize',13)


