load Hipp_data.mat

% plot position and firing
s1Ind = find(spikes);
s2Ind = find(spikes2);
plot(xN,yN,xN(s1Ind),yN(s1Ind),'.r', xN(s2Ind),yN(s2Ind),'.g');
legend({'Position' 'Firing neuron interest' 'Firing 2nd neuron'}, ...
     'location','BestOutside' )
set(gca,'fontsize',15)
axis tight square;


%% Spatial model 1
X = [xN yN];
[b,dev,stats] = glmfit(X,spikes,'poisson');
stats.p

lambdaEst = exp(b(1) +  X*b(2:end) );
clf
ksStat = doKStest(lambdaEst,spikes)